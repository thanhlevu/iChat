// Student Name:  THANH LE
// Student ID:    1706203
// ChatHistoryObserver interface to print out messages
interface ChatHistoryObserver {
    fun newMessage(message:String)
}