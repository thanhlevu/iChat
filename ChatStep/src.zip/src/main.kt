import java.net.Socket
// Student Name:  THANH LE
// Student ID:    1706203
// this main function to start the program by calling ChatServer().serve() method, connect to server
fun main(args: Array<String>) {
    ChatServer().serve()
}
